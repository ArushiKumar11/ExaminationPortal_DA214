
import { createSlice } from '@reduxjs/toolkit';

export const examSlice = createSlice({
  name: 'exam',
  initialState: {
    examId: null,
    details: {},
  },
  reducers: {
    setExamId: (state, action) => {
      state.examId = action.payload;
    },
    setExamDetails: (state, action) => {
      state.details = action.payload;
    },
  },
});

export const { setExamId, setExamDetails } = examSlice.actions;

export default examSlice.reducer;
