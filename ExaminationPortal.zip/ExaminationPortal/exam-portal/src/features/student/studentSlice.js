// src/features/student/studentSlice.js
import { createSlice } from '@reduxjs/toolkit';

export const studentSlice = createSlice({
  name: 'student',
  initialState: {
    studentId: null,
    details: {},
  },
  reducers: {
    setStudentId: (state, action) => {
      state.studentId = action.payload;
    },
    setStudentDetails: (state, action) => {
      state.details = action.payload;
    },
  },
});

export const { setStudentId, setStudentDetails } = studentSlice.actions;

export default studentSlice.reducer;
