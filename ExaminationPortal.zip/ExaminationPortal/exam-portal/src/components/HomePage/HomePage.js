import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HomePage.css';

function HomePage()
{
    const navigate = useNavigate();
    return(
        <div className="home-container">
            <h1>Welcome to Exam Monitoring System</h1>
            <p>Your one stop destination for online exams</p>
            <button onClick={() => navigate('/studentregister')}>Student Register</button>
            <button onClick={() => navigate('/student-login')}>Student Login</button>
            <button onClick={() => navigate('/add-exam')}>Admin Register</button>
            <button onClick={() => navigate('/admin-login')}>Admin Login</button>
            
        </div>
    );

}

export default HomePage;