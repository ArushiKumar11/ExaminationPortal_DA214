import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const ExamsList = () => {
    const [exams, setExams] = useState([]);
    const [scheduledDateTime, setScheduledDateTime] = useState('');
    const navigate = useNavigate();
    const studentId = useSelector((state) => state.student.studentId); // Assumed to be set post-login

    useEffect(() => {
        // Fetch available exams
        fetch('http://localhost:5000/available-exams')
            .then((res) => res.json())
            .then(setExams)
            .catch((err) => console.error("Fetching exams failed:", err));
    }, []);

    const scheduleExam = (examId) => {
        if (!scheduledDateTime) {
            alert('Please select a date and time for the exam.');
            return;
        }
        fetch('http://localhost:5000/schedule-exam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ studentId, examId, scheduledTime: scheduledDateTime })
        })
        .then((res) => {
            if (!res.ok) {
                throw new Error('Scheduling exam failed');
            }
            return res.json();
        })
        .then(() => {
            alert('Exam scheduled successfully');
            navigate('/student-dashboard'); // Redirect or handle post-scheduling
        })
        .catch((err) => alert(err.message));
    };

    return (
        <div>
            <h2>Available Exams</h2>
            {exams.map((exam) => (
                <div key={exam.exam_id}>
                    <h3>{exam.exam_name}</h3>
                    <input
                        type="datetime-local"
                        value={scheduledDateTime}
                        onChange={(e) => setScheduledDateTime(e.target.value)}
                    />
                    <button onClick={() => scheduleExam(exam.exam_id)}>Schedule</button>
                </div>
            ))}
        </div>
    );
};

export default ExamsList;
