import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './ExamPage.css'; 

function ExamPage() {
    const { sessionId } = useParams();
    const [questions, setQuestions] = useState([]);
    const [totalTime, setTotalTime] = useState(0);
     const [isLoading, setIsLoading] = useState(true);
    const [remainingTime, setRemainingTime] = useState(0);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
     const [startTime, setStartTime] = useState(Date.now());
    const [userAnswers, setUserAnswers] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
  const fetchExamDetails = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`http://localhost:5000/exam-questions/${sessionId}`);
      if (!response.ok) throw new Error('Failed to fetch exam details');
      const data = await response.json();
      setQuestions(data.questions.map(q => ({ ...q, options: JSON.parse(q.options) })));
      setTotalTime(data.totalTime*60);
      setRemainingTime(data.totalTime*60);
    } catch (error) {
      console.error("Error fetching exam details:", error);
    }
    setIsLoading(false);
  };
  fetchExamDetails();
}, [sessionId]);

    useEffect(() => {
        if(!isLoading && totalTime>0){
        if (remainingTime > 0) {

            const timer = setTimeout(() => setRemainingTime(remainingTime - 1), 1000);
            return () => clearTimeout(timer);
        } else {
            handleSubmit(); // Submit exam when time runs out
        }
    }}, [remainingTime,totalTime,isLoading]);

  const handleAnswerChange = (questionId, optionIndex) => {
  const endTime = Date.now();
  const timeTaken = Math.floor((endTime - startTime) / 1000); // Time taken in seconds

  setUserAnswers(prevAnswers => ({
    ...prevAnswers,
    [questionId]: {
      selectedOption: optionIndex + 1, // Adjust for 1-indexed answers
      timeTaken
    }
  }));

  setStartTime(endTime); // Reset startTime for the next question
};
   const handleSubmit = async () => {
    try {
const payload = {
      sessionId,
      answers: userAnswers, // This already includes both selectedOption and timeTaken for each question
    };
      const response = await fetch(`http://localhost:5000/submit-answers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
           sessionId,
        answers: userAnswers
        })
      });
      if (!response.ok) throw new Error('Failed to submit answers');
      navigate('/results-page'); // Navigate to the results page or home
    } catch (error) {
      console.error("Error submitting answers:", error);
      // Handle submission error (e.g., show a message to the user)
    }
  };

    if (isLoading|| questions.length === 0) return <div>Loading questions...</div>;

    const currentQuestion = questions[currentQuestionIndex];

    return (
        <div className="exam-page">
            <div className="timer">
                Time Remaining: {Math.floor(remainingTime / 60)}:{String(remainingTime % 60).padStart(2, '0')}
            </div>
            <div className="question-section">
                <h2>Question {currentQuestionIndex + 1}</h2>
                <p>{currentQuestion.question}</p>
                {currentQuestion.options.map((option, index) => (
                    <label key={index} className="options-container">
                        <input
                            type="radio"
                            name="answer"
                            value={index + 1} // value is the option number (1-indexed)
              checked={userAnswers[currentQuestion.question_id] === index + 1}
                            onChange={() => handleAnswerChange(currentQuestion.question_id, index)}
                        />
                        {option}
                    </label>
                ))}
            </div>
            <div className="navigation-buttons">
                <button disabled={currentQuestionIndex === 0} onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}>Previous</button>
                <button disabled={currentQuestionIndex === questions.length - 1} onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}>Next</button>
                {currentQuestionIndex === questions.length - 1 && (
                    <button onClick={handleSubmit}>Submit Exam</button>
                )}
            </div>
        </div>
    );
}

export default ExamPage;
