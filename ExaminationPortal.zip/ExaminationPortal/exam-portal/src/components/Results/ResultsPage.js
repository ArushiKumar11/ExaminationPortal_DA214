import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

function ResultsPage() {
    const { sessionId } = useParams();
    const [results, setResults] = useState(null);

    useEffect(() => {
        fetch(`http://localhost:5000/exam-results/${sessionId}`)
            .then(res => res.json())
            .then(data => setResults(data))
            .catch(err => console.error("Error fetching exam results:", err));
    }, [sessionId]);

    if (!results) return <div>Loading results...</div>;

    return (
        <div>
            <h1>Exam Results</h1>
            <p>Score: {results.obtainedScore} / {results.totalScore}</p>
            <h2>Question Wise Performance</h2>
            {results.details.map((detail, index) => (
                <div key={index}>
                    <p><strong>Question:</strong> {detail.question}</p>
                    <p><strong>Your Answer:</strong> {detail.selectedOption}</p>
                    <p><strong>Correct Answer:</strong> {detail.correctAnswer}</p>
                     <p><strong>TimeTaken:</strong> {detail.timeTaken}</p>
                    <p><strong>Score:</strong> {detail.obtainedPoints} / {detail.totalPoints}</p>
                    <p><strong>Difficulty:</strong> {detail.difficulty}</p>
                </div>
            ))}
        </div>
    );
}

export default ResultsPage;
