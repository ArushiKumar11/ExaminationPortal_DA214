import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setStudentDetails } from '../../features/student/studentSlice';
import { useNavigate } from 'react-router-dom';
import './StudentDashboard.css';

function StudentDashboard() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const studentDetails = useSelector((state) => state.student.details);
    const studentId = useSelector((state) => state.student.studentId);
    const [scheduledExams, setScheduledExams] = useState([]);

    useEffect(() => {
        if (studentId) {
            const fetchStudentDetails = async () => {
                try {
                    const response = await fetch(`http://localhost:5000/student-details/${studentId}`);
                    if (!response.ok) {
                        throw new Error('Failed to fetch student details');
                    }
                    const data = await response.json();
                    dispatch(setStudentDetails(data));
                } catch (error) {
                    console.error('Error fetching student details:', error);
                    alert(`An error occurred while fetching student details: ${error.message}`);
                }
            };
            fetchStudentDetails();
            
            // Fetch scheduled exams including their completion status
            const fetchScheduledExams = async () => {
                try {
                    const response = await fetch(`http://localhost:5000/scheduled-exams/${studentId}`);
                    if (!response.ok) {
                        throw new Error('Failed to fetch scheduled exams');
                    }
                    const exams = await response.json();
                    setScheduledExams(exams);
                } catch (error) {
                    console.error('Failed to fetch scheduled exams:', error);
                }
            };
            fetchScheduledExams();
        }
    }, [dispatch, studentId]);

    const handleExamAction = (exam) => {
        if (exam.is_completed) {
            navigate(`/results/${exam.session_id}`);
        } else {
            navigate(`/exam-session/${exam.session_id}`);
        }
    };

    return (
        <div className="student-dashboard">
            <div className="profile-card">
                <h2>My Profile</h2>
                <p><strong>Name:</strong> {studentDetails?.name}</p>
                <p><strong>Email:</strong> {studentDetails?.email}</p>
                <p><strong>Education Level:</strong> {studentDetails?.educationLevel}</p>
            </div>
            <button onClick={() => navigate('/exams')} className="view-exams-btn">View and Book Exams</button>
            <h2>Your Scheduled Exams</h2>
            <div className="scheduled-exams-list">
                {scheduledExams.length > 0 ? scheduledExams.map((exam) => (
                    <div key={exam.session_id} className="scheduled-exam-entry">
                        <h3>{exam.exam_name}</h3>
                        <p>Scheduled Time: {new Date(exam.scheduled_time).toLocaleString()}</p>
                        <button onClick={() => handleExamAction(exam)}>
                            {exam.is_completed ? 'View Results' : 'Start Exam'}
                        </button>
                    </div>
                )) : <p>No exams scheduled.</p>}
            </div>
        </div>
    );
}

export default StudentDashboard;
