// src/components/StudentRegistration/StudentRegistration.js
import React, { useState } from 'react';
import './StudentRegistration.css';

function StudentRegistration() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        educationLevel: '',
        educationStatus: '',
        completionYear: '',
        schoolName: '',
        major: '',
    });

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

      const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch('http://localhost:5000/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });
            if (response.ok) {
                const result = await response.json();
                console.log(result);
                alert('Registration successful!');
                // Optionally reset the form or handle the navigation after registration
                setFormData({
                    name: '',
                    email: '',
                    password: '',
                    educationLevel: '',
                    educationStatus: '',
                    completionYear: '',
                    schoolName: '',
                    major: '',
                });
                // If you have routing set up, you might navigate to the login page or another route here.
            } else {
                // Handle errors here
                const errorResult = await response.json();
                console.error('Registration failed:', errorResult);
                alert('Registration failed. Please try again.');
            }
        } catch (error) {
            console.error('There was an error submitting the form:', error);
            alert('An error occurred. Please try again.');
        }
    };
    return (
        
        <div className="registration-container">
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label className="label" htmlFor="name">Name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label className="label" htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label className="label" htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                {/* Additional form fields for education details */}
                <div className="form-group">
                    <label className="label" htmlFor="educationLevel">Highest Education Level</label>
                    <select
                        id="educationLevel"
                        name="educationLevel"
                        value={formData.educationLevel}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select</option>
                        <option value="highSchool">High School</option>
                        <option value="bachelors">Bachelors</option>
                        <option value="masters">Masters</option>
                    </select>
                </div>
                {formData.educationLevel && (
                    <>
                        <div className="form-group">
                            <label className="label">Education Status</label>
                            <input
                                type="radio"
                                id="ongoing"
                                name="educationStatus"
                                value="ongoing"
                                onChange={handleChange}
                                checked={formData.educationStatus === 'ongoing'}
                            /> <label htmlFor="ongoing">Ongoing</label>
                            <input
                                type="radio"
                                id="completed"
                                name="educationStatus"
                                value="completed"
                                onChange={handleChange}
                                checked={formData.educationStatus === 'completed'}
                            /> <label htmlFor="completed">Completed</label>
                        </div>
                        {formData.educationStatus === 'completed' && (
                            <div className="form-group">
                                <label className="label" htmlFor="completionYear">Completion Year</label>
                                <input
                                    type="number"
                                    id="completionYear"
                                    name="completionYear"
                                    value={formData.completionYear}
                                    onChange={handleChange}
                                    required={formData.educationStatus === 'completed'}
                                />
                            </div>
                        )}
                    </>
                )}
                <div className="form-group">
                    <label className="label" htmlFor="schoolName">School/College Name</label>
                    <input
                        type="text"
                        id="schoolName"
                        name="schoolName"
                        value={formData.schoolName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label className="label" htmlFor="major">Major</label>
                    <input
                        type="text"
                        id="major"
                        name="major"
                        value={formData.major}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit">Register</button>
            </form>
        </div>
    );

   
}

export default StudentRegistration;
