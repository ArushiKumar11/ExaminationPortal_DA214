import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setExamDetails } from '../../features/exam/examSlice';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css';

function AdminDashboard() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const examDetails = useSelector((state) => state.exam.details);
    const examId = useSelector((state) => state.exam.examId);

    // Define fetchStudentDetails outside of useEffect
    const fetchExamDetails = async () => {
        try {
            
            const response = await fetch(`http://localhost:5000/exam-details/${examId}`);

            if (!response.ok) {
                throw new Error('Failed to fetch student details');
            }

            const data = await response.json();
            dispatch(setExamDetails(data)); // Dispatch action to set student details in Redux store
        } catch (error) {
            console.error('Error fetching exam details:', error);
            alert(`An error occurred while fetching student details: ${error.message}`);
        }
    };

    // Corrected useEffect
    useEffect(() => {
        if (examId && (!examDetails || Object.keys(examDetails).length === 0)) {
            fetchExamDetails();
        }
    }, [examId, examDetails, dispatch]); // Removed fetchStudentDetails from dependencies

    const handleViewExams = () => {
        // Navigate to exams page
        navigate('/exams');
    };

    return (
        <div className="student-dashboard">
            <div className="profile-card">
                <h2>My Profile</h2>
                <p><strong>Name:</strong> {examDetails?.name}</p>
                <p><strong>Email:</strong> {examDetails?.email}</p>
                <p><strong>Exam Name:</strong> {examDetails?.examName}</p>
                {/* More profile details */}
            </div>
            <button onClick={handleViewExams} className="view-exams-btn">View and Book Exams</button>
        </div>
    );
}

export default AdminDashboard;
