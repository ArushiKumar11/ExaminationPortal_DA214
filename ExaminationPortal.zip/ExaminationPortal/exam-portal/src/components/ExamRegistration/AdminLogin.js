import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminLogin.css';
import { useDispatch } from 'react-redux'; // Import useDispatch from react-redux

import { setExamId, setExamDetails } from '../../features/exam/examSlice';



function AdminLogin() {
    const [credentials, setCredentials] = useState({ email: '', password: '' });
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCredentials({ ...credentials, [name]: value });
    };

    
        const handleSubmit = async (e) => {
    e.preventDefault();
    try {
        const response = await fetch('http://localhost:5000/admin-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(credentials),
        });

        if (response.ok) {
    const result = await response.json();
    if (result.success) {
        dispatch(setExamId(result.examId));
        dispatch(setExamDetails(result.examDetails)); // Dispatch action to set student ID
        alert('Login successful!');
        navigate('/admin-dashboard');
    } else {
        alert('Invalid credentials');
    }
}
    } catch (error) {
        console.error('Login error:', error);
        alert(error.message || 'An error occurred during login'); // Display error message
    }
};
    

    return (
        <div className="student-login-container">
            <h2>Admin Login</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="email"
                    name="email"
                    value={credentials.email}
                    onChange={handleChange}
                    placeholder="Email"
                    required
                    className="login-input"
                />
                <input
                    type="password"
                    name="password"
                    value={credentials.password}
                    onChange={handleChange}
                    placeholder="Password"
                    required
                    className="login-input"
                />
                <button type="submit" className="login-button">Login</button>
            </form>
        </div>
    );
}

export default AdminLogin;
