import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import { useLocation } from 'react-router-dom'; 
import './AddQuestion.css';

function AddQuestion() {
    const [questionData, setQuestionData] = useState({
       examId: useLocation().state.examId,
        question: '',
        options: JSON.stringify(['', '', '', '']),
        correctAnswer: '',
        totalPoints: '',
        topic: '',
        difficulty: 1,
    });
    const [questionAdded, setQuestionAdded] = useState(false);

    const navigate = useNavigate();
   
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setQuestionData(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleOptionsChange = (optionValue, index) => {
        let options = JSON.parse(questionData.options);
        options[index] = optionValue;
        setQuestionData(prevState => ({
            ...prevState,
            options: JSON.stringify(options),
        }));
    };
    const handleCorrectAnswerChange = (e) => {
        setQuestionData(prevState => ({
            ...prevState,
            correctAnswer: e.target.value,
        }));
    };


    const addAnotherQuestion = () => {
        setQuestionAdded(false);
        setQuestionData(prevState => ({
            ...prevState,
            question: '',
            options: JSON.stringify(['', '', '', '']),
            correctAnswer: '',
            totalPoints: '',
            topic: '',
            difficulty: 1,
        }));
    };

    const finishCreatingTest = () => {
        navigate('/'); // Assuming '/' is the route to your homepage or exams list
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            questionData.correctAnswer = parseInt(questionData.correctAnswer) + 1;

            const response = await fetch('http://localhost:5000/add-question', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(questionData),
            });

            if (!response.ok) throw new Error('Problem adding question');

            setQuestionAdded(true);
            alert('Question added successfully');
        } catch (error) {
            console.error('Failed to add question:', error);
            alert('Failed to add question');
        }
    };

    return (
        <div className="add-question-container">
            <h2>Add Question to Exam</h2>
            {!questionAdded ? (
                <form onSubmit={handleSubmit}>
                    <div>
                    <label>Question:</label>
                    <input
                        type="text"
                        name="question"
                        value={questionData.question}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                {[...Array(4)].map((_, index) => (
                    <div key={index}>
                        <label>Option {index + 1}:</label>
                        <input
                            type="text"
                            value={JSON.parse(questionData.options)[index]}
                            onChange={(e) => handleOptionsChange(e.target.value, index)}
                            required
                        />
                    </div>
                ))}
                <div>
                    <label>Correct Answer:</label>
                    <select
                        type="text"
                        name="correctAnswer"
                        value={questionData.correctAnswer}
                        onChange={handleCorrectAnswerChange}
                        required
                    >
                        <option value="">Select the correct option</option>
                            {[...Array(4)].map((_, index) => (
                                <option key={index} value={String(index)}>
                                    Option {index + 1}
                                </option>
                            ))}

                        </select>
                </div>
                <div>
                    <label>Total Points:</label>
                    <input
                        type="number"
                        name="totalPoints"
                        value={questionData.totalPoints}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div>
                    <label>Topic:</label>
                    <input
                        type="text"
                        name="topic"
                        value={questionData.topic}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                <div>
                    <label>Difficulty (1-5):</label>
                    <input
                        type="number"
                        name="difficulty"
                        min="1"
                        max="5"
                        value={questionData.difficulty}
                        onChange={handleInputChange}
                        required
                    />
                </div>
                    {/* Form inputs and labels here */}
                    <button type="submit">Add Question</button>
                </form>
            ) : (
                <div>
                    <p>Question Added Successfully!</p>
                    <button onClick={addAnotherQuestion}>Add Another Question</button>
                    <button onClick={finishCreatingTest}>Done! Create Test</button>
                </div>
            )}
        </div>
    );
}

export default AddQuestion;
