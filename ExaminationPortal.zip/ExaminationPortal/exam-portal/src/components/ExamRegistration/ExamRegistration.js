import React, { useState } from 'react';
import './ExamRegistration.css';
import { useNavigate } from 'react-router-dom';


function ExamRegistration() {
    const [formData, setFormData] = useState({
        adminName: '',
        adminEmail: '',
        adminPassword: '',
        examName: '',
        examTopics: [],
        totalTime: '',
       
       
    });
    const navigate = useNavigate();

    const handleChange = (event) => {
        const { name, value, type } = event.target;
        
        
            setFormData({ ...formData, [name]: value });
        
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const response = await fetch('http://localhost:5000/registerExam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(
                formData)   
            ,
        });
        if (response.ok) {
        const result = await response.json();
        console.log(result); // Log the result here
        if (result.examId !== null) {
            alert('Exam registered successfully!');
            navigate(`/add-question`, { state: { examId: result.examId } });
            
        } else {
            alert('ExamId is null in the response');
        }
    } else {
        alert('Failed to register the exam.');
    }
    };

    return (
        <div className="registration-container">
        <form onSubmit={handleSubmit}>
            {/* Other input fields */}
            <div className="form-group">
                    <label className="label" htmlFor="name">Name</label>
                    <input
                        type="text"
                        id="name"
                        name="adminName"
                        value={formData.adminName}
                        onChange={handleChange}
                        required
                    />
                </div>
           <div className="form-group">
                    <label className="label" htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="adminEmail"
                        value={formData.adminEmail}
                        onChange={handleChange}
                        required
                    />
                </div>
            
            <div className="form-group">
                    <label className="label" htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="adminPassword"
                        value={formData.adminPassword}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label className="label" htmlFor="name"> Exam Name</label>
                    <input
                        type="text"
                        id="name"
                        name="examName"
                        value={formData.examName}
                        onChange={handleChange}
                        required
                    />
                </div>
                 
                 <div className="form-group">
                    <label className="label" htmlFor="name">Total Time(Minutes)</label>
                    <input
                        type="number"
                        id="name"
                        name="totalTime"
                        value={formData.totalTime}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label className="label" htmlFor="name">Exam Topics</label>
                    <input
                        type="text"
                        id="name"
                        name="examTopics"
                        value={formData.examTopics}
                        onChange={handleChange}
                        required
                    />
                </div>
            
            
            

            
           

            
            <button type="submit">Register Exam</button>
        </form>
        </div>
    );
}

export default ExamRegistration;
