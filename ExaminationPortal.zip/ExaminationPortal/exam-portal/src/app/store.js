// src/app/store.js
import { configureStore } from '@reduxjs/toolkit';
import studentReducer from '../features/student/studentSlice';
import examReducer from '../features/exam/examSlice';


export const store = configureStore({
  reducer: {
    student: studentReducer,
    exam: examReducer,
  },
});
