

import React from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import './App.css';
import HomePage from './components/HomePage/HomePage';
import StudentRegistration from './components/StudentRegistration/StudentRegistration';
import ExamRegistration from './components/ExamRegistration/ExamRegistration';
import AddQuestion from './components/ExamRegistration/AddQuestion';
import StudentLogin from './components/StudentRegistration/StudentLogin';
import AdminLogin from './components/ExamRegistration/AdminLogin';
import StudentDashboard from './components/StudentDashboard/StudentDashboard';
import AdminDashboard from './components/ExamRegistration/AdminDashboard';
import ExamsList from './components/ExamSession/ExamsList';
import ExamPage from './components/ExamSession/ExamPage';
import ResultsPage from './components/Results/ResultsPage';



function App()
{
  return(
    <Router>
      <div className="App">
        <Routes>
          <Route path="studentregister" element ={<StudentRegistration/>} />
          <Route path='student-login' element={<StudentLogin/>}/>
          <Route path="/" element ={<HomePage/>} />
          <Route path="add-exam" element={<ExamRegistration/>} />
          <Route path="add-question" element={<AddQuestion/>} />
          <Route path="admin-login" element={<AdminLogin/>} />
          <Route path="student-dashboard" element={<StudentDashboard />} />
          <Route path="admin-dashboard" element={<AdminDashboard />} />
          <Route path="/exams" element={<ExamsList />} />
         
<Route path="/exam-session/:sessionId" element={<ExamPage />} />
<Route path="/results/:sessionId" element={<ResultsPage />} />


        
        </Routes>
      </div>
    </Router>
   
  );
}

export default App;
