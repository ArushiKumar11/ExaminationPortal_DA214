// server.js



// Add this at the top of your server.js
const db = require('./database');

// Registration endpoint


const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json()); // For parsing application/json

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


app.post('/registerExam', (req, res) => {
    const { adminName, adminEmail,adminPassword, examName, examTopics, totalTime} = req.body;
    const query = `INSERT INTO exams (admin_name, admin_email,admin_password, exam_name, exam_topics, total_time) VALUES (?, ?, ?, ?, ?, ?)`;
    
    db.query(query, [adminName, adminEmail,adminPassword, examName, examTopics, totalTime], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).json({ message: 'Error registering exam', error: err.toString() });
            return;
        }
        res.status(200).json({ message: 'Exam registered successfully', examId: result.insertId });
    });
});

app.post('/add-question', (req, res) => {
    const { examId, question, options, correctAnswer, totalPoints, topic, difficulty } = req.body;
    const query = `INSERT INTO questions (exam_id, question, options, correct_answer, total_points, topic, difficulty) VALUES (?, ?, ?, ?, ?, ?, ?)`;
    
    db.query(query, [examId, question, JSON.stringify(options), correctAnswer, totalPoints, topic, difficulty], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).json({ message: 'Error adding question', error: err.toString() });
            return;
        }
        res.status(200).json({ message: 'Question added successfully' });
    });
});
app.post('/student-login', (req, res) => {
    const { email, password } = req.body;
    const query = "SELECT * FROM students WHERE email = ? AND password = ?";

    db.query(query, [email, password], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).json({ success: false, message: "Database query error", error: err.toString() });
            return;
        }

        if (result.length > 0) {
            const student = result[0];
            res.json({
                success: true,
                message: "Login successful",
                studentId: student.id, // Assuming 'id' is the name of the ID column in your students table
                studentDetails: { // Return the necessary student details
                    name: student.name,
                    email: student.email,
                    educationLevel: student.educationLevel,

                    // Include other details as needed
                }
            });
        } else {
            res.status(401).json({ success: false, message: "Invalid credentials" });
        }
    });
});

app.post('/admin-login', (req, res) => {
    const { email, password } = req.body;
    const query = "SELECT * FROM exams WHERE admin_email = ? AND admin_password = ?";

    db.query(query, [email, password], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).json({ success: false, message: "Database query error", error: err.toString() });
            return;
        }

        if (result.length > 0) {
            const exams = result[0];
            res.json({
                success: true,
                message: "Login successful",
               examId: exams.exam_id, // Assuming 'id' is the name of the ID column in your students table
                examDetails: { // Return the necessary student details
                    name: exams.admin_name,
                    email: exams.admin_email,
                    examName: exams.exam_name,
                    
                    // Include other details as needed
                }
            });
        } else {
            res.status(401).json({ success: false, message: "Invalid credentials" });
        }
    });
});


app.post('/register', (req, res) => {
  const { name, email, password, educationLevel, educationStatus, completionYear, schoolName, major } = req.body;
  // Here you would typically hash the password before storing it
  const query = `INSERT INTO students (name, email, password, educationLevel, educationStatus, completionYear, schoolName, major) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  db.query(query, [name, email, password, educationLevel, educationStatus, completionYear, schoolName, major], (err, result) => {
    if (err) {
      // Don't throw the error, instead send a JSON response with the error
      console.error(err);
      res.status(500).json({ message: 'Error registering user', error: err });
    } else {
      // Send a JSON response indicating success
      res.status(200).json({ message: 'Registration successful',examId: result.insertId });
    }
  });
});

app.get('/student-details/:studentId', (req, res) => {
    const { studentId } = req.params;
    const query = "SELECT * FROM students WHERE id = ?";
    
    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error('Error fetching student details:', err);
            res.status(500).json({ message: "Error fetching student details", error: err });
        } else if (results.length > 0) {
            
            res.json(results[0]);
        } else {
            // If no results, the student was not found
            res.status(404).json({ message: "Student not found" });
        }
    });
});

app.get('/exam-details/:examId', (req, res) => {
    const { examId } = req.params;
    const query = "SELECT * FROM exams WHERE exam_id = ?";
    
    db.query(query, [examId], (err, results) => {
        if (err) {
            console.error('Error fetching admin details:', err);
            res.status(500).json({ message: "Error fetching admin details", error: err });
        } else if (results.length > 0) {
            
            res.json(results[0]);
        } else {
            // If no results, the student was not found
            res.status(404).json({ message: "Admin not found" });
        }
    });
});

// In server.js

app.get('/available-exams', (req, res) => {
    db.query('SELECT exam_id, exam_name, total_time, exam_topics FROM exams', (err, results) => {
        if (err) {
            console.error('Error fetching exams:', err);
            return res.status(500).json({ message: "Error fetching exams", error: err.toString() });
        }
        res.json(results);
    });
});

// In server.js
app.post('/schedule-exam', (req, res) => {
    const { studentId, examId, scheduledTime } = req.body; // Assume scheduledTime is passed for simplicity
    db.query('INSERT INTO exam_sessions (student_id, exam_id, scheduled_time) VALUES (?, ?, ?)', [studentId, examId, scheduledTime], (err, result) => {
        if (err) {
            console.error('Error scheduling exam:', err);
            return res.status(500).json({ message: "Error scheduling exam", error: err.toString() });
        }
        res.json({ message: 'Exam scheduled successfully', sessionId: result.insertId });
    });
});

app.get('/scheduled-exams/:studentId', (req, res) => {
    const { studentId } = req.params;
    const query = `
        SELECT es.session_id, es.scheduled_time, e.exam_name, e.total_time, e.exam_topics, es.is_completed
        FROM exam_sessions es
        JOIN exams e ON es.exam_id = e.exam_id
        WHERE es.student_id = ?;
    `;

    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error('Error fetching scheduled exams:', err);
            return res.status(500).json({ message: "Error fetching scheduled exams", error: err.toString() });
        }
        res.json(results);
    });
});



app.get('/exam-questions/:sessionId', (req, res) => {
    const { sessionId } = req.params;
    // Updated query to include total_time from the exams table
    const query = `
        SELECT q.question_id, q.question, q.options, q.total_points, e.total_time
        FROM questions q
        JOIN exam_sessions es ON q.exam_id = es.exam_id
        JOIN exams e ON es.exam_id = e.exam_id
        WHERE es.session_id = ?;
    `;
    db.query(query, [sessionId], (err, results) => {
        if (err) {
            console.error('Error fetching questions:', err);
            res.status(500).send('Error fetching questions');
            return;
        }
        // Assuming all questions will have the same total_time, so we take the total_time from the first result
        const totalTime =results[0].total_time;
        const questions = results.map(q => ({ ...q, options: JSON.parse(q.options) }));
        res.json({ questions, totalTime }); // Send both questions and total time in the response
    });
});


app.post('/submit-answers', (req, res) => {
    const { sessionId, answers } = req.body; // `answers` should be an object with structure: { questionId: { selectedOption, timeTaken }, ... }

    const promises = Object.entries(answers).map(([questionId, { selectedOption, timeTaken }]) => {
        return new Promise((resolve, reject) => {
            const getQuestionQuery = `SELECT correct_answer, total_points FROM questions WHERE question_id = ?`;
            db.query(getQuestionQuery, [questionId], (err, results) => {
                if (err) {
                    return reject(err);
                }
                const question = results[0];
                let score = 0;
                if (question.correct_answer === selectedOption) {
                    score = question.total_points;
                }
                const insertResponseQuery = `INSERT INTO user_responses (session_id, question_id, selected_option, time_taken, score) VALUES (?, ?, ?, ?, ?)`;
                db.query(insertResponseQuery, [sessionId, questionId, selectedOption, timeTaken, score], (err) => {
                    if (err) {
                        return reject(err);
                    }
                    resolve();
                });
            });
        });
    });

    Promise.all(promises)
        .then(() => {
            res.json({ message: "Answers submitted successfully." });
        })
        .catch((error) => {
            console.error('Error submitting answers:', error);
            res.status(500).json({ message: "Error processing answers", error: error.toString() });
        });
});

// Assuming you have set up Express and MySQL connection as `db`

app.get('/exam-results/:sessionId', (req, res) => {
    const { sessionId } = req.params;

    db.query(`
        SELECT 
            q.question, 
            q.correct_answer, 
            ur.selected_option, 
            ur.time_taken
            q.total_points, 
            ur.score, 
            q.difficulty 
        FROM user_responses ur 
        JOIN questions q ON ur.question_id = q.question_id 
        WHERE ur.session_id = ?`, [sessionId], 
        (error, questionsResults) => {
            if (error) {
                console.error('Error fetching questions results:', error);
                return res.status(500).json({ message: "Error fetching exam results", error: error.toString() });
            }

            const obtainedScore = questionsResults.reduce((acc, curr) => acc + curr.score, 0);
            const totalScore = questionsResults.reduce((acc, curr) => acc + curr.total_points, 0);

            res.json({
                obtainedScore,
                totalScore,
                details: questionsResults.map(qr => ({
                    question: qr.question,
                    correctAnswer: qr.correct_answer,
                    selectedOption: qr.selected_option,
                    timeTaken :ur.time_taken,
                    obtainedPoints: qr.score,
                    totalPoints: qr.total_points,
                    difficulty: qr.difficulty
                }))
            });
        }
    );
});
